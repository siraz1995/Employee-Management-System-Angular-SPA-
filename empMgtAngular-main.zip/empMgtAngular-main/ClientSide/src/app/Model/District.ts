export class District{
    public districtId : number = 0
    public districtName : string = ""
    public divisionId : number = 0
}