export class EmploymentInfo{
    public id : number;
    public employeeId : number;
    public departmentId : number;
    public designation : string;
    public isNew : boolean;
    public salary : number;
    public referenceName : string;
    public referencePhone : number ;
}