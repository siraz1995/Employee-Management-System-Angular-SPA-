export class EducationalInfo{
    public id : number 
    public employeeId : number 
    public highestDegree : string = ""
    public subject : string = ""
    public passingYear : number 
    public cgpa : number 
    public training : string = ""
    public duration : string = ""
}