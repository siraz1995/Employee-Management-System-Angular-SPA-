export class Department{
    public departmentId : number = 0
    public depName : string = ""
}