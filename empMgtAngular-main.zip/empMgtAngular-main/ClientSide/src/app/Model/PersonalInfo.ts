export class PersonalInfo{
    public employeeId : number;
    public name : string ;
    public doB : Date = new Date()
    public gender : string;
    public phone : number;
    public email : string;
    public address : string;
    public divisionId : number ;
    public districtId : number ;
    public image : string;
}