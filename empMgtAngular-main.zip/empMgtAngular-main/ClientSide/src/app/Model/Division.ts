export class Division{
    public divisionId : number = 0
    public divName : string = ""
}